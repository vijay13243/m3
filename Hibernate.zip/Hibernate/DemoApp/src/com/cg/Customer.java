package com.cg;

public class Customer {

}
