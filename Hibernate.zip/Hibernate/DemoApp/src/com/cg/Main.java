package com.cg;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

public class Main {

	public static void main(String[] args) {
		
		EntityManagerFactory factory= Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		
		//Inserting into the Table
		//		Employess emp =new Employess(103,"Priyanka","Female", 22, 1000000);
//		em.getTransaction().begin();
//		em.persist(emp);
//		em.getTransaction().commit();
//		System.out.println("Data Saved");
		//Searching into the table
//		Employess emp=em.find(Employess.class, 103);
//		System.out.println(emp);
		
		//Searching and Updating the value
//		Employess emp=em.find(Employess.class,101);
//		System.out.println(emp);
//		em.getTransaction().begin();
//		emp.setSalary(1000);
//		em.getTransaction().commit();
//		System.out.println("After Commit");
//		System.out.println(emp); 
		
		//Remove From Employee
		/*Employess emp=em.find(Employess.class, 101);
		System.out.println(emp);
		em.remove(emp);
		em.getTransaction().commit();
		System.out.println("After Comimit");*/
		
		//Use of Persist
		/*Employess emp=new Employess(106,"Priya","Female", 22, 17000);
		System.out.println(emp);
		em.getTransaction().begin();
		
		emp.setAge(21);
		emp.setSalary(20000);
		em.persist(emp);
		em.getTransaction().commit();
		System.out.println("Updating");
		System.out.println(emp);*/
		
		/*em.getTransaction().begin();
		Employess e=em.find(Employess.class, 102);
		System.out.println(e);
		
		em.detach(e);
		e.setAge(35);
		em.merge(e);
		
		em.getTransaction().commit();
		System.out.println("After Commit");
		System.out.println(e);*/
		
	//	em.clear(); Clear all the object from presistance Context.
	//	em.remove(e); It will only Marked the Object but Only Removed when commit() is used after it.
		
		Employee em2=new Employee();
		em2.setName("Vijay");
		em2.setGender("Male");
		em2.setAge(22);
		em2.setSalary(29057);
		
		em.getTransaction().begin();
		em.persist(em2);
		em.getTransaction().commit();
		System.out.println(em2);
		System.out.println(em2);

	}

}
