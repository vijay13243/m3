package com.bens;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;


public class Dao implements ServiceEmp {
	
	
	
	
	/*public void insertCommand(List<Bens> list){
		
		
		
	}
	*/
	@Override
	public void addEmp(Bens b) {
EntityManager em1=connection();
		
		
			em1.getTransaction().begin();
		
		em1.persist(b);
		em1.getTransaction().commit();
		System.out.println("Data Saved");
		}
		
	

	public static EntityManager connection(){
		EntityManagerFactory factory= Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		return em;
	}
}
