/*package com.bens;

import java.util.ArrayList;
import java.util.List;

public class DaoList implements ServiceEmp {
	
	Dao d1=new Dao();
	Bens b1=new Bens();
	List<Bens> list=new ArrayList<Bens>();
	@Override
	public void addEmp(Bens b) {
		
		
	}
	
}
*/