package com.bens;

public interface ServiceEmp {
	public void addEmp(Bens b);
	
}
