package com.bens;

public class TestMain {

	public static void main(String[] args) {
		/*List<Bens> list=new ArrayList<Bens>();*/
		Bens b1=new Bens(1057,"Anil","Male",22,20000);
		Bens b2=new Bens(1306,"Anil","Male",22,20000);
		/*list.add(b1);*/
		/*list.add(b2);*/
		Dao d=new Dao();
		d.addEmp(b1);
		d.addEmp(b2);

	}

}
