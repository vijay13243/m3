package com.bens;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.JoinTable;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

import org.hibernate.annotations.Cascade;

@Entity
public class Faculty {
	@Id
	@GeneratedValue
	private int id;
	private String name;
	/*@OneToOne(cascade=CascadeType.ALL)
	@JoinColumn(name="TechId")*/
	@ManyToMany(cascade=CascadeType.PERSIST,fetch=FetchType.EAGER)
	@JoinTable(name="factTech",joinColumns=@JoinColumn(name= "facId"),
	inverseJoinColumns=@JoinColumn(name="techId"))
	private List<Technology> technologies=new ArrayList<>();
	
	
	
	
	public List<Technology> getTechnologies() {
		return technologies;
	}

	public void setTechnologies(List<Technology> technologies) {
		this.technologies = technologies;
	}

	/*private Technology Techii;*/
	public Faculty(String name) {
		super();
		this.name = name;
		
	}
	
/*	public Technology getTechii() {
		return Techii;
	}

	public void setTechii(Technology techii) {
		Techii = techii;
	}*/

	public Faculty(){}

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "Faculty [id=" + id + ", name=" + name + "]";
	}
	
	
}
