package com.bens;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.ManyToMany;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Technology {

	@Id
	@GeneratedValue
	private int techId;
	private String techName;
	/* @OneToOne(mappedBy="Techii") */

	/*
	 * private Faculty faculty;
	 * 
	 * public Faculty getFaculty() { return faculty; } public void
	 * setFaculty(Faculty faculty) { this.faculty = faculty; }
	 */
	@ManyToMany
	private List<Faculty> faculties=new ArrayList<>();
	
	public List<Faculty> getFaculties() {
		return faculties;
	}public void setFaculties(List<Faculty> faculties) {
		this.faculties = faculties;
	}
	public int getTechId() {
		return techId;
	}

	public void setTechId(int techId) {
		this.techId = techId;
	}

	public Technology(String techName) {
		super();
		this.techName = techName;
	}

	public Technology() {
		// TODO Auto-generated constructor stub
	}

	public String getTechName() {
		return techName;
	}

	public void setTechName(String techName) {
		this.techName = techName;
	}

	@Override
	public String toString() {
		return "Technology [techId=" + techId + ", techName=" + techName + "]";
	}

}
