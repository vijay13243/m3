package com.mains;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.bens.Faculty;
import com.bens.Technology;

public class Main2 {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		
		EntityManager em=factory.createEntityManager();
		/*em.getTransaction().begin();*/
	
	/*	
		Technology tech=new Technology("Java");
		Faculty faculty=new Faculty("Anil");
		faculty.setTechii(tech);
		em.persist(faculty);
		em.persist(tech);
		em.getTransaction().commit();
		*/
		
	/*	Faculty fac=new Faculty();
		fac.setName("Varsha");*/
		/*Technology tech=new Technology("JAVA");
		tech.setFaculty(fac);
		fac.setTechii(tech);*/
		/*Technology tech1=new Technology();
		tech1.setTechName("JAVA");
		Technology tech2=new Technology();
		tech2.setTechName("BDD");
		fac.getTechnologies().add(tech1);
		fac.getTechnologies().add(tech2);     
		
		em.getTransaction().begin();
		
		em.persist(fac);
		
		em.getTransaction().commit();
		*/
		/*
		Faculty fac=em.find(Faculty.class, 1);
		
		System.out.println(fac);
		
		for (Technology tech : fac.getTechnologies()) {
			System.out.println(tech);
			
		}*/
		Faculty fac1=new Faculty();
		fac1.setName("Varsha");
		Faculty fac2=new Faculty();
		fac2.setName("Reni");
		Technology tech1=new Technology("JAVA");
		Technology tech2=new Technology("BDD");
		fac1.getTechnologies().add(tech1);
		fac1.getTechnologies().add(tech2);
		fac2.getTechnologies().add(tech1);
		fac2.getTechnologies().add(tech2);
		tech1.getFaculties().add(fac1);
		tech1.getFaculties().add(fac2);
		tech2.getFaculties().add(fac1);
		tech2.getFaculties().add(fac2);
		em.getTransaction().begin();
		
		
		
		
		

	}

}
