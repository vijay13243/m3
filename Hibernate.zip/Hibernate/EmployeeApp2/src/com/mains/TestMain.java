package com.mains;

import java.util.List;
import java.util.Scanner;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import javax.persistence.TypedQuery;

import com.bens.Bens;

public class TestMain {

	public static void main(String[] args) {
		/*EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		TypedQuery<Bens> tq=em.createQuery("from Bens", Bens.class);
	//	TypedQuery<Bens> tq=em.createQuery("select ben from Bens ben", Bens.class);
		List<Bens> list=tq.getResultList();
		

		for(Bens bens:list){
		System.out.println(bens);
		}*/
		
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		Scanner scanner=new Scanner(System.in);
		/*System.out.println("Enter Gender");
		
		String gender=scanner.nextLine();
		TypedQuery<Bens> query=em.createQuery("from Bens where gender=?", Bens.class);
		
		TypedQuery<Bens> query=em.createQuery("from Bens where gender=:gen", Bens.class);
		query.setParameter("gen", gender);
		List<Bens> list=query.getResultList();
		System.out.println(list);*/
		
		
		//	Delete Query
		/*System.out.println("Enter Employee Id");
		int emId=scanner.nextInt();
		
		Query query=em.createQuery("delete from Bens where id=:eno");
		query.setParameter("eno", emId);
		em.getTransaction().begin();
		int result=query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(result+"row deleted");*/
		
		// Getting Single Result at a time 
		/*
		System.out.println("Enter Employee Id");
		int emId=scanner.nextInt();
		
		TypedQuery<Bens> query=em.createQuery("from Bens where id=:eno", Bens.class);
		query.setParameter("eno", emId);
		Bens ben=query.getSingleResult();
		System.out.println(ben);*/
		
		//Updating the List of employee with increasing salary, age whose Gender is Male/Female
		/*System.out.println("Enter Gender Id");
		String gen=scanner.nextLine();
		
		System.out.println("Enter Salary");
		float sal=scanner.nextFloat();
		
		System.out.println("Enter age ");
		int ageNum = scanner.nextInt();
		
		Query query=em.createQuery("update Bens set salary=salary+:s, age=age+:a where gender=:g");
		
		query.setParameter("s", sal);
		query.setParameter("a",ageNum);
		query.setParameter("g", gen);
		em.getTransaction().begin();
		int result=query.executeUpdate();
		em.getTransaction().commit();
		System.out.println(result+"row(s) Updated");*/
		
		
		//Using NamedQuery
		/*TypedQuery<Bens> queryy=em.createNamedQuery("getAllBens", Bens.class);
		List<Bens> list=queryy.getResultList();
		
		for(Bens ben:list){
			System.out.println(ben);
		}*/
		
		Query query=em.createNamedQuery("getByGender");
		query.setParameter("gen", "Female");
		
		List<Bens> list2=query.getResultList();
		for (Bens bens : list2) {
			System.out.println(bens);
		}
		
	}

}
