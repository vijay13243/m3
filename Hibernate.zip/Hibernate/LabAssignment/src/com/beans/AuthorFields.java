package com.beans;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name="Author")
public class AuthorFields {
	@Id
	@GeneratedValue
	private int authorid;
	private String firstName;
	private String middleName;
	private String lastName;
	private String phoneNo;
	
	
	public AuthorFields() {
		
	}


	public AuthorFields(int authorid, String firstName, String middleName, String lastName, String phoneNo) {
		
		this.authorid = authorid;
		this.firstName = firstName;
		this.middleName = middleName;
		this.lastName = lastName;
		this.phoneNo = phoneNo;
	}


	public int getAuthorid() {
		return authorid;
	}


	public void setAuthorid(int authorid) {
		this.authorid = authorid;
	}


	public String getFirstName() {
		return firstName;
	}


	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}


	public String getMiddleName() {
		return middleName;
	}


	public void setMiddleName(String middleName) {
		this.middleName = middleName;
	}


	public String getLastName() {
		return lastName;
	}


	public void setLastName(String lastName) {
		this.lastName = lastName;
	}


	public String getPhoneNo() {
		return phoneNo;
	}


	public void setPhoneNo(String phoneNo) {
		this.phoneNo = phoneNo;
	}


	@Override
	public String toString() {
		return "Author [authorid=" + authorid + ", firstName=" + firstName + ", middleName=" + middleName
				+ ", lastName=" + lastName + ", phoneNo=" + phoneNo + "]";
	}
	
	

}
