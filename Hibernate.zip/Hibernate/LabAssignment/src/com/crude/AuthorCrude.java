package com.crude;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.beans.AuthorFields;

public class AuthorCrude {

	public void Insertion(List<AuthorFields> list) {
		EntityManager e = connection();
		for (AuthorFields authorFields : list) {
			e.getTransaction().begin();
			e.persist(authorFields);
			e.getTransaction().commit();
		}

	}

	public void Deletion(int AId) {
		EntityManager e = connection();
		e.getTransaction().begin();
		AuthorFields ab = e.find(AuthorFields.class, AId);
		e.remove(ab);
		e.getTransaction().commit();
		System.out.println(ab+"Deleted");
	}
	
	public void Update(int AId,String firstName,String phoneNumber){
		EntityManager e = connection();
		e.getTransaction().begin();
		AuthorFields ab = e.find(AuthorFields.class, AId);
		ab.setFirstName(firstName);
		ab.setPhoneNo(phoneNumber);
		e.getTransaction().commit();
		System.out.println(ab+"Updated");
	}

	public EntityManager connection() {
		EntityManagerFactory factory = Persistence.createEntityManagerFactory("JPA-PU");

		EntityManager em = factory.createEntityManager();
		return em;
	}
}
