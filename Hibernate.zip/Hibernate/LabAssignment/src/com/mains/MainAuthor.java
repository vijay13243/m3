package com.mains;

import java.util.ArrayList;
import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;

import com.beans.AuthorFields;
import com.crude.AuthorCrude;

public class MainAuthor {

	public static void main(String[] args) {
		EntityManagerFactory factory=Persistence.createEntityManagerFactory("JPA-PU");
		EntityManager em=factory.createEntityManager();
		AuthorCrude AC=new AuthorCrude();
		
		List<AuthorFields> list=new ArrayList<>();
		AuthorFields aF=new AuthorFields();
		aF.setFirstName("Ramendra");
		aF.setMiddleName("Kumar");
		aF.setLastName("Jha");
		aF.setPhoneNo("7290999545");
		
		list.add(aF);
		/*AC.Insertion(list);
		
*/		//AC.Deletion(1);
		AC.Update(2, "Ram", "123456789");
		/*em.getTransaction().begin();
		em.persist(aF);
		em.getTransaction().commit();*/

	}

}
